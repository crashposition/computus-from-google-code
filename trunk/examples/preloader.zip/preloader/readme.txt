====================================================================================
2009 | John Dalziel  | The Computus Engine  |  http://www.computus.org

All source code licenced under The MIT Licence
====================================================================================  
	

AS3 Animated main preloader example
------------------------------------------------------------------------------------

How to:
1. Create a new FLA and give it a document class of org.computus.utils.preloader.MainPreloader
2. Create a MovieClip with 100 frames of animation.
3. Open its linkage properties in the library and give it a class name of "ProgressGraphic".
4. Compile and 'simulate download' to watch the preloader animation play



source code:
------------------------------------------------------------------------------------
http://code.google.com/p/computus/


More info:
------------------------------------------------------------------------------------
Creating a main preloader in Flash CS3
http://www.computus.org/journal/?p=21

Creating an animated main preloader in Flash CS3
http://www.computus.org/journal/?p=18


